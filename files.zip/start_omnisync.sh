#!/bin/bash
echo "🚀 Запуск OmniSync Interface"
node websocket_server.js &
node discord_bot.js &
python3 -m http.server 8080